import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'galleryapp';
  selectImg:any;
  img:any=[
    {imageName:"img1", path:"/assets/img/img1.jpg"},
    
    {imageName:"img12", path:"/assets/img/img12.jpg"},
    
    {imageName:"img13", path:"/assets/img/img13.jpg"},
    
    {imageName:"img14", path:"/assets/img/img14.jpg"},
    
    {imageName:"img15", path:"/assets/img/img15.jpg"},
    {imageName:"img16", path:"/assets/img/img16.jpg"},
    
    {imageName:"img17", path:"/assets/img/img17.jpg"},

  ];

    showImge(image) : void {
      this.selectImg=image.path;
    }
  constructor(){
    this.selectImg=this.img[0].path;
    console.log(this.img);      
  }
}
